"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[73629],{73629:(e,t,r)=>{r.r(t),r.d(t,{default:()=>C});var n=r(54568),i=r(99680),s=r(1105),a=r(7411),o=r(7620),u=r(10025),l=r(33197);let v=e=>e===Object(e)&&!Array.isArray(e)&&"function"!=typeof e;function c(e,t){let r=(0,l.D)(e=>e.gl),n=(0,l.H)(u.Tap,v(e)?Object.values(e):e);return(0,o.useLayoutEffect)(()=>{null==t||t(n)},[t]),(0,o.useEffect)(()=>{if("initTexture"in r){let e=[];Array.isArray(n)?e=n:n instanceof u.gPd?e=[n]:v(n)&&(e=Object.values(n)),e.forEach(e=>{e instanceof u.gPd&&r.initTexture(e)})}},[r,n]),(0,o.useMemo)(()=>{if(!v(e))return n;{let t={},r=0;for(let i in e)t[i]=n[r++];return t}},[e,n])}c.preload=e=>l.H.preload(u.Tap,e),c.clear=e=>l.H.clear(u.Tap,e);var f=r(35207);let m={uniforms:{tDiffuse:{value:null},h:{value:1/512}},vertexShader:`
      varying vec2 vUv;

      void main() {

        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

      }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float h;

    varying vec2 vUv;

    void main() {

    	vec4 sum = vec4( 0.0 );

    	sum += texture2D( tDiffuse, vec2( vUv.x - 4.0 * h, vUv.y ) ) * 0.051;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 4.0 * h, vUv.y ) ) * 0.051;

    	gl_FragColor = sum;

    }
  `},p={uniforms:{tDiffuse:{value:null},v:{value:1/512}},vertexShader:`
    varying vec2 vUv;

    void main() {

      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

    }
  `,fragmentShader:`

  uniform sampler2D tDiffuse;
  uniform float v;

  varying vec2 vUv;

  void main() {

    vec4 sum = vec4( 0.0 );

    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 4.0 * v ) ) * 0.051;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 4.0 * v ) ) * 0.051;

    gl_FragColor = sum;

  }
  `},x=o.forwardRef(({scale:e=10,frames:t=1/0,opacity:r=1,width:n=1,height:i=1,blur:s=1,near:a=0,far:v=10,resolution:c=512,smooth:x=!0,color:d="#000000",depthWrite:h=!1,renderOrder:y,...g},D)=>{let U,j,b=o.useRef(null),S=(0,l.D)(e=>e.scene),w=(0,l.D)(e=>e.gl),M=o.useRef(null);n*=Array.isArray(e)?e[0]:e||1,i*=Array.isArray(e)?e[1]:e||1;let[A,P,R,T,_,k,C]=o.useMemo(()=>{let e=new u.nWS(c,c),t=new u.nWS(c,c);t.texture.generateMipmaps=e.texture.generateMipmaps=!1;let r=new u.bdM(n,i).rotateX(Math.PI/2),s=new u.eaF(r),a=new u.CSG;a.depthTest=a.depthWrite=!1,a.onBeforeCompile=e=>{e.uniforms={...e.uniforms,ucolor:{value:new u.Q1f(d)}},e.fragmentShader=e.fragmentShader.replace("void main() {",`uniform vec3 ucolor;
           void main() {
          `),e.fragmentShader=e.fragmentShader.replace("vec4( vec3( 1.0 - fragCoordZ ), opacity );","vec4( ucolor * fragCoordZ * 2.0, ( 1.0 - fragCoordZ ) * 1.0 );")};let o=new u.BKk(m),l=new u.BKk(p);return l.depthTest=o.depthTest=!1,[e,r,a,s,o,l,t]},[c,n,i,e,d]),E=e=>{T.visible=!0,T.material=_,_.uniforms.tDiffuse.value=A.texture,_.uniforms.h.value=e/256,w.setRenderTarget(C),w.render(T,M.current),T.material=k,k.uniforms.tDiffuse.value=C.texture,k.uniforms.v.value=e/256,w.setRenderTarget(A),w.render(T,M.current),T.visible=!1},F=0;return(0,l.F)(()=>{M.current&&(1/0===t||F<t)&&(F++,U=S.background,j=S.overrideMaterial,b.current.visible=!1,S.background=null,S.overrideMaterial=R,w.setRenderTarget(A),w.render(S,M.current),E(s),x&&E(.4*s),w.setRenderTarget(null),b.current.visible=!0,S.overrideMaterial=j,S.background=U)}),o.useImperativeHandle(D,()=>b.current,[]),o.createElement("group",(0,f.A)({"rotation-x":Math.PI/2},g,{ref:b}),o.createElement("mesh",{renderOrder:y,geometry:P,scale:[1,-1,1],rotation:[-Math.PI/2,0,0]},o.createElement("meshBasicMaterial",{transparent:!0,map:A.texture,opacity:r,depthWrite:h})),o.createElement("orthographicCamera",{ref:M,args:[-n/2,n/2,i/2,-i/2,a,v]}))});var d=r(62389),h=r(35539),y=r(60805),g=r(9160),D=r(47852);function U(e){let t,r,s=(0,i.c)(4),{url:o}=e,l=(0,a.p)(o);if(s[0]!==l.scene){t=l.scene.clone(!0);let e=new u.NRn().setFromObject(t),r=new u.Pq0,n=new u.Pq0;e.getSize(r),e.getCenter(n);let i=1.8/(r.y||1);t.scale.setScalar(i),t.position.set(-n.x*i,-e.min.y*i,-n.z*i),s[0]=l.scene,s[1]=t}else t=s[1];let v=t;return s[2]!==v?(r=(0,n.jsx)("primitive",{object:v}),s[2]=v,s[3]=r):r=s[3],r}function j(e){let t,r,s,l,v=(0,i.c)(9),{url:c,mixerRef:f}=e,m=(0,a.p)(c);if(v[0]!==m.scene){t=m.scene.clone(!0);let e=new u.NRn().setFromObject(t),r=new u.Pq0,n=new u.Pq0;e.getSize(r),e.getCenter(n);let i=3.06/(r.y||1);t.scale.setScalar(i),t.position.set(-n.x*i+0,-n.y*i+.9+0,-n.z*i+.15),t.traverse(b),v[0]=m.scene,v[1]=t}else t=v[1];let p=t;return v[2]!==m.animations||v[3]!==f||v[4]!==p?(r=()=>{if(!m.animations.length){f.current=null;return}let e=new u.Iw4(p);for(let t of m.animations)e.clipAction(t).play();return f.current=e,()=>{e.stopAllAction(),f.current=null}},s=[p,m.animations,f],v[2]=m.animations,v[3]=f,v[4]=p,v[5]=r,v[6]=s):(r=v[5],s=v[6]),(0,o.useEffect)(r,s),v[7]!==p?(l=(0,n.jsx)("primitive",{object:p}),v[7]=p,v[8]=l):l=v[8],l}function b(e){if(e.isMesh)for(let t of Array.isArray(e.material)?e.material:[e.material])"emissiveIntensity"in t&&(t.emissiveIntensity=2.5),t.toneMapped=!1}function S(e){let t,r,s,a=(0,i.c)(4),{url:o}=e,u=c(o);return a[0]===Symbol.for("react.memo_cache_sentinel")?(t=[0,4,-8],r=(0,n.jsx)("planeGeometry",{args:[24,13.5]}),a[0]=t,a[1]=r):(t=a[0],r=a[1]),a[2]!==u?(s=(0,n.jsxs)("mesh",{position:t,children:[r,(0,n.jsx)("meshBasicMaterial",{map:u,toneMapped:!1})]}),a[2]=u,a[3]=s):s=a[3],s}function w(e){let t,r=(0,i.c)(8),{storyboard:n,sequence:s,scrubSec:a,playing:u,enabled:v,onShot:c,mixerRef:f}=e,m=(0,o.useRef)("");return r[0]!==v||r[1]!==f||r[2]!==c||r[3]!==u||r[4]!==a||r[5]!==s||r[6]!==n?(t=(e,t)=>{let r;if(!v)return;if(null!=a)E(s,a),r=a;else{if(u){let e=s.position+t;n.duration>0&&e>n.duration&&(e%=n.duration),E(s,e)}r=s.position}let i=(0,D.jb)(n,r),o=e.camera;o.position.set(i.position[0],i.position[1],i.position[2]),o.lookAt(i.target[0],i.target[1],i.target[2]),o.isPerspectiveCamera&&o.fov!==i.fov&&(o.fov=i.fov,o.updateProjectionMatrix());let l=f.current;l&&l.setTime(r%(n.duration||1)),c&&i.shotName!==m.current&&(m.current=i.shotName,c(i.shotName))},r[0]=v,r[1]=f,r[2]=c,r[3]=u,r[4]=a,r[5]=s,r[6]=n,r[7]=t):t=r[7],(0,l.F)(t),null}function M(e){let t,r,n=(0,i.c)(9),{sequence:s,onReady:a}=e,u=(0,l.D)(_),v=(0,l.D)(T),c=(0,l.D)(R),f=(0,l.D)(P),m=(0,l.D)(A);return n[0]!==f||n[1]!==c||n[2]!==u||n[3]!==a||n[4]!==v||n[5]!==s||n[6]!==m?(t=()=>{a?.({gl:u,scene:v,camera:c,advance:f,sequence:s,setFrameloop:e=>m(e)})},r=[u,v,c,f,s,m,a],n[0]=f,n[1]=c,n[2]=u,n[3]=a,n[4]=v,n[5]=s,n[6]=m,n[7]=t,n[8]=r):(t=n[7],r=n[8]),(0,o.useEffect)(t,r),null}function A(e){return e.setFrameloop}function P(e){return e.advance}function R(e){return e.camera}function T(e){return e.scene}function _(e){return e.gl}function k(e){let{playerUrl:t,effectUrl:r,storyboard:i,backdropUrl:a,bloom:u=!0,orbit:l=!1}=e,v=(0,o.useMemo)(()=>(r.split("/").pop()??r).replace(/\.glb$/i,"")||"demo-composed",[r]),c=(0,o.useMemo)(()=>(0,y.getProject)("azalee-cutin").sheet(v),[v]),f=c.sequence,m=(0,o.useRef)(null);return(0,o.useEffect)(()=>{E(f,0)},[f,i.duration]),(0,o.useEffect)(()=>{},[]),(0,n.jsxs)(g.DB,{sheet:c,children:[(0,n.jsx)("hemisphereLight",{args:[0xffffff,3356746,1.1]}),(0,n.jsx)("ambientLight",{intensity:.35}),(0,n.jsx)("directionalLight",{position:[3,5,4],intensity:1.6,castShadow:!0}),(0,n.jsx)("directionalLight",{position:[-4,2,-3],intensity:.8,color:0xbcd0ff}),(0,n.jsxs)("mesh",{"rotation-x":-Math.PI/2,"position-y":0,receiveShadow:!0,children:[(0,n.jsx)("planeGeometry",{args:[40,40]}),(0,n.jsx)("meshStandardMaterial",{color:"#2e6b3a"})]}),(0,n.jsx)(x,{position:[0,.001,0],opacity:.55,scale:10,blur:2.4,far:4,resolution:1024,color:"#05210f"}),(0,n.jsxs)(o.Suspense,{fallback:null,children:[(0,n.jsx)(U,{url:t}),(0,n.jsx)(j,{url:r,mixerRef:m}),a?(0,n.jsx)(S,{url:a}):null]}),(0,n.jsx)(w,{storyboard:i,sequence:f,scrubSec:e.scrubSec,playing:e.playing??!1,enabled:!l,onShot:e.onShot,mixerRef:m}),l&&(0,n.jsx)(d.N,{makeDefault:!0,enableDamping:!0,target:[0,.9,0]}),u&&(0,n.jsx)(s.s0,{children:(0,n.jsx)(s.mK,{mipmapBlur:!0,luminanceThreshold:1,intensity:1.4,kernelSize:3})}),(0,n.jsx)(M,{sequence:f,onReady:e.onReady})]})}function C(e){let t,r,s,a,o=(0,i.c)(5);return o[0]===Symbol.for("react.memo_cache_sentinel")?(t={preserveDrawingBuffer:!0},o[0]=t):t=o[0],o[1]===Symbol.for("react.memo_cache_sentinel")?(r={fov:38,position:[0,1,4]},s=[1,2],o[1]=r,o[2]=s):(r=o[1],s=o[2]),o[3]!==e?(a=(0,n.jsx)(h.Hl,{frameloop:"always",shadows:!0,gl:t,camera:r,dpr:s,children:(0,n.jsx)(k,{...e})}),o[3]=e,o[4]=a):a=o[4],a}function E(e,t){e.position=t}}}]);