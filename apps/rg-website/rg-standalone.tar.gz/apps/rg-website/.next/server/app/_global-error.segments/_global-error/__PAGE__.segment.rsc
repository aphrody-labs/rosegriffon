1:"LoadingBoundaryProvider"
2:I[92532,[],"$1"]
3:"$Sreact.fragment"
4:I[92532,[],""]
5:"static/chunks/10933-de91d0151d2921f4.js"
6:"static/chunks/28701-6588b48e0143c42f.js"
7:"static/chunks/37442-bd89708fa9b80324.js"
8:"static/chunks/22429-d88ad330266b96be.js"
9:"static/chunks/app/error-1e44f860d4d6e088.js"
a:I[65255,["10933","$5","28701","$6","37442","$7","22429","$8","18039","$9"],"default"]
b:I[67986,[],""]
c:"static/chunks/51050-c8a9b1e91d207db3.js"
d:"static/chunks/70655-b85dd16db5d158bb.js"
e:"static/chunks/72187-75b4ec90501a3d0a.js"
f:"static/chunks/38642-f995ef77947ec6cb.js"
10:"static/chunks/44906-ca4cc08a33324b87.js"
11:"static/chunks/app/not-found-c5c2e665ca0d9f3d.js"
12:I[69836,["10933","$5","28701","$6","37442","$7","22429","$8","51050","$c","70655","$d","72187","$e","38642","$f","44906","$10","24345","$11"],"default"]
1e:"ViewportBoundary"
1f:I[95633,[],"$1e"]
20:"MetadataBoundary"
21:I[95633,[],"$20"]
22:"$Sreact.suspense"
14:X
14:C
15:X
18:[["children",{"s":"__PAGE__","h":176,"d":{"r":["$","$3","c",{"children":[["$","html",null,{"id":"__next_error__","children":[["$","head",null,{"children":[["$","title",null,{"children":"500: This page couldn’t load"}],["$","style",null,{"dangerouslySetInnerHTML":{"__html":":root {--next-error-bg: #fff;--next-error-text: #171717;--next-error-title: #171717;--next-error-message: #171717;--next-error-digest: #666666;--next-error-btn-text: #fff;--next-error-btn-bg: #171717;--next-error-btn-border: none;--next-error-btn-secondary-text: #171717;--next-error-btn-secondary-bg: transparent;--next-error-btn-secondary-border: 1px solid rgba(0,0,0,0.08);}@media (prefers-color-scheme: dark) {:root {--next-error-bg: #0a0a0a;--next-error-text: #ededed;--next-error-title: #ededed;--next-error-message: #ededed;--next-error-digest: #a0a0a0;--next-error-btn-text: #0a0a0a;--next-error-btn-bg: #ededed;--next-error-btn-border: none;--next-error-btn-secondary-text: #ededed;--next-error-btn-secondary-bg: transparent;--next-error-btn-secondary-border: 1px solid rgba(255,255,255,0.14);}}body { margin: 0; color: var(--next-error-text); background: var(--next-error-bg); }"}}]]}],["$","body",null,{"children":["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","display":"flex","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"style":{"marginTop":"-32px","maxWidth":"325px","padding":"32px 28px","textAlign":"left"},"children":[["$","svg",null,{"width":"32","height":"32","viewBox":"-0.2 -1.5 32 32","fill":"none","style":{"marginBottom":"24px"},"children":["$","path",null,{"d":"M16.9328 0C18.0839 0.000116771 19.1334 0.658832 19.634 1.69531L31.4299 26.1309C32.0708 27.4588 31.1036 28.9999 29.6291 29H2.00215C0.527541 29 -0.439628 27.4588 0.201371 26.1309L11.9973 1.69531C12.4979 0.658823 13.5474 7.75066e-05 14.6984 0H16.9328ZM3.59493 26H28.0363L16.9328 3H14.6984L3.59493 26ZM15.8156 19C16.9202 19.0001 17.8156 19.8955 17.8156 21C17.8156 22.1045 16.9202 22.9999 15.8156 23C14.7111 23 13.8156 22.1046 13.8156 21C13.8156 19.8954 14.7111 19 15.8156 19ZM17.3156 16.5H14.3156V8.5H17.3156V16.5Z","fill":"var(--next-error-title)"}]}],"$L19","$L1a","$L1b"]}]}]}]]}],null,"$L1c"]}],"p":"$@1d","v":null,"s":"$15"}}]]
16:[["children",{"s":"_global-error","h":112,"d":{"r":["$","$3","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$Lb",null,{}]}]]}],"p":"$@17","v":"$14","s":"$15"},"c":"$Q18"}]]
0:{"t":{"t":{"s":"","h":84,"d":{"r":["$","$L2",null,{"loading":[["$","div","l",{"className":"min-h-screen space-y-6 px-4 py-4 min-[600px]:space-y-8 min-[600px]:px-6","children":[["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse h-12 w-full rounded-2xl min-[600px]:hidden"}],[["$","section","1",{"className":"space-y-4 rounded-3xl border p-4 min-[600px]:p-6","children":[["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse size-11 rounded-xl"}],["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse rounded-md h-7 w-40"}]]}],["$","div",null,{"className":"grid gap-3 min-[840px]:grid-cols-2","children":[["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse h-64 w-full rounded-2xl"}],["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse h-64 w-full rounded-2xl"}]]}]]}],["$","section","2",{"className":"space-y-4 rounded-3xl border p-4 min-[600px]:p-6","children":[["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse size-11 rounded-xl"}],["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse rounded-md h-7 w-40"}]]}],["$","div",null,{"className":"grid gap-3 min-[840px]:grid-cols-2","children":[["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse h-64 w-full rounded-2xl"}],["$","div",null,{"data-slot":"skeleton","className":"bg-accent animate-pulse h-64 w-full rounded-2xl"}]]}]]}]]]}],[],null],"children":["$","$3","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$a","errorStyles":[],"errorScripts":null,"template":["$","$Lb",null,{}],"notFound":[["$","$L12",null,{}],[]]}]]}]}],"p":"$@13","v":"$14","s":"$15"},"c":"$Q16"},"h":{"r":["$","$3","h",{"children":[null,["$","$L1f",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L21",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$22",null,{"name":"Next.Metadata","children":[]}]}],null]}],null]}],"p":"$@23","v":null,"s":"$15"}},"a":"$@24","u":"$@25","b":"XkWNZ8Nblkk2AAx1dIYEE"}
26:I[95633,[],"OutletBoundary"]
19:["$","h1",null,{"style":{"fontSize":"24px","fontWeight":500,"letterSpacing":"-0.02em","lineHeight":"32px","margin":"0 0 12px 0","color":"var(--next-error-title)"},"children":"This page couldn’t load"}]
1a:["$","p",null,{"style":{"fontSize":"14px","fontWeight":400,"lineHeight":"21px","margin":"0 0 20px 0","color":"var(--next-error-message)"},"children":"A server error occurred. Reload to try again."}]
1b:["$","form",null,{"style":{"margin":0},"children":["$","button",null,{"type":"submit","style":{"display":"inline-flex","alignItems":"center","justifyContent":"center","height":"32px","padding":"0 12px","fontSize":"14px","fontWeight":500,"lineHeight":"20px","borderRadius":"6px","cursor":"pointer","color":"var(--next-error-btn-text)","background":"var(--next-error-btn-bg)","border":"var(--next-error-btn-border)"},"children":"Reload"}]}]
1c:["$","$L26",null,{"children":["$","$22",null,{"name":"Next.MetadataOutlet","children":"$@27"}]}]
15:300
27:null
25:true
15:C
24:0
17:"$undefined"
13:"$undefined"
23:"$undefined"
1d:"$undefined"
