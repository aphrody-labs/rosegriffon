self.__SERVER_FILES_MANIFEST={
  "version": 1,
  "config": {
    "env": {
      "NIE_CDN_BASE": "https://cdn.rosegriffon.fr"
    },
    "typescript": {
      "ignoreBuildErrors": true
    },
    "typedRoutes": false,
    "distDir": ".next",
    "cleanDistDir": true,
    "assetPrefix": "",
    "cacheMaxMemorySize": 52428800,
    "configOrigin": "next.config.ts",
    "useFileSystemPublicRoutes": true,
    "generateEtags": true,
    "pageExtensions": [
      "tsx",
      "ts",
      "jsx",
      "js"
    ],
    "instrumentationClientInject": [],
    "poweredByHeader": false,
    "compress": false,
    "images": {
      "deviceSizes": [
        768,
        1024,
        1920
      ],
      "imageSizes": [
        96,
        256,
        384,
        512
      ],
      "path": "/_next/image",
      "loader": "default",
      "loaderFile": "",
      "domains": [],
      "disableStaticImages": false,
      "minimumCacheTTL": 2678400,
      "formats": [
        "image/webp"
      ],
      "maximumRedirects": 3,
      "maximumResponseBody": 50000000,
      "dangerouslyAllowLocalIP": false,
      "dangerouslyAllowSVG": true,
      "contentSecurityPolicy": "default-src 'self'; script-src 'none'; sandbox;",
      "contentDispositionType": "attachment",
      "localPatterns": [
        {
          "pathname": "**",
          "search": ""
        }
      ],
      "remotePatterns": [
        {
          "protocol": "https",
          "hostname": "cdn.rosegriffon.fr"
        },
        {
          "protocol": "https",
          "hostname": "*.supabase.co",
          "pathname": "/storage/v1/**"
        },
        {
          "protocol": "https",
          "hostname": "placehold.co"
        },
        {
          "protocol": "https",
          "hostname": "rosegriffon.fr"
        },
        {
          "protocol": "https",
          "hostname": "azalee.rosegriffon.fr"
        },
        {
          "protocol": "https",
          "hostname": "achillea.rosegriffon.fr"
        },
        {
          "protocol": "https",
          "hostname": "cdn.discordapp.com"
        },
        {
          "protocol": "https",
          "hostname": "static-cdn.jtvnw.net"
        },
        {
          "protocol": "https",
          "hostname": "vod-secure.twitch.tv"
        },
        {
          "protocol": "https",
          "hostname": "clips-media-assets2.twitch.tv"
        },
        {
          "protocol": "https",
          "hostname": "pbs.twimg.com"
        },
        {
          "protocol": "https",
          "hostname": "abs.twimg.com"
        },
        {
          "protocol": "https",
          "hostname": "dxi4wb638ujep.cloudfront.net"
        },
        {
          "protocol": "https",
          "hostname": "www.inazuma.jp"
        },
        {
          "protocol": "https",
          "hostname": "zukan.inazuma.jp"
        },
        {
          "protocol": "https",
          "hostname": "inazuma.jp"
        },
        {
          "protocol": "https",
          "hostname": "lh3.googleusercontent.com"
        }
      ],
      "qualities": [
        70,
        75,
        90,
        95,
        100
      ],
      "unoptimized": false,
      "customCacheHandler": false
    },
    "devIndicators": {
      "position": "bottom-left"
    },
    "onDemandEntries": {
      "maxInactiveAge": 60000,
      "pagesBufferLength": 5
    },
    "basePath": "",
    "sassOptions": {},
    "trailingSlash": false,
    "i18n": null,
    "productionBrowserSourceMaps": false,
    "excludeDefaultMomentLocales": true,
    "reactProductionProfiling": false,
    "reactStrictMode": null,
    "reactMaxHeadersLength": 6000,
    "httpAgentOptions": {
      "keepAlive": true
    },
    "logging": {
      "serverFunctions": true,
      "browserToTerminal": "warn"
    },
    "compiler": {
      "removeConsole": {
        "exclude": [
          "error",
          "warn"
        ]
      }
    },
    "expireTime": 31536000,
    "staticPageGenerationTimeout": 60,
    "output": "standalone",
    "modularizeImports": {
      "@mui/icons-material": {
        "transform": "@mui/icons-material/{{member}}"
      },
      "lodash": {
        "transform": "lodash/{{member}}"
      }
    },
    "outputFileTracingRoot": "C:\\src\\apps\\rosegriffon",
    "enablePrerenderSourceMaps": true,
    "cacheComponents": false,
    "cacheLife": {
      "default": {
        "stale": 300,
        "revalidate": 900,
        "expire": 4294967294
      },
      "seconds": {
        "stale": 30,
        "revalidate": 1,
        "expire": 60
      },
      "minutes": {
        "stale": 300,
        "revalidate": 60,
        "expire": 3600
      },
      "hours": {
        "stale": 300,
        "revalidate": 3600,
        "expire": 86400
      },
      "days": {
        "stale": 300,
        "revalidate": 86400,
        "expire": 604800
      },
      "weeks": {
        "stale": 300,
        "revalidate": 604800,
        "expire": 2592000
      },
      "max": {
        "stale": 300,
        "revalidate": 2592000,
        "expire": 31536000
      }
    },
    "cacheHandlers": {},
    "deprecated": {},
    "experimental": {
      "agentUpgrade": "security",
      "agentFeedback": false,
      "coldCacheBadge": false,
      "collapseAdapterRoutes": true,
      "devValidationWorker": true,
      "useSkewCookie": false,
      "cssChunking": true,
      "multiZoneDraftMode": false,
      "appNavFailHandling": false,
      "parallelRouteMetadata": false,
      "prerenderEarlyExit": true,
      "serverMinification": true,
      "linkNoTouchStart": false,
      "caseSensitiveRoutes": false,
      "cachedNavigations": false,
      "dynamicOnHover": false,
      "reactBrowserBailout": true,
      "useOffline": false,
      "varyParams": true,
      "optimisticRouting": true,
      "concurrentRouterQueue": false,
      "instrumentationClientRouterTransitionEvents": false,
      "prefetchInlining": {
        "maxSize": 2048,
        "maxBundleSize": 10240
      },
      "preloadEntriesOnStart": true,
      "clientRouterFilter": true,
      "clientRouterFilterRedirects": false,
      "fetchCacheKeyPrefix": "",
      "proxyPrefetch": "flexible",
      "optimisticClientCache": true,
      "manualClientBasePath": false,
      "cpus": 2,
      "memoryBasedWorkersCount": false,
      "imgOptConcurrency": null,
      "imgOptOperationCache": null,
      "imgOptTimeoutInSeconds": 7,
      "imgOptMaxInputPixels": 268402689,
      "imgOptSequentialRead": null,
      "imgOptMozjpeg": true,
      "isrFlushToDisk": true,
      "workerThreads": false,
      "optimizeCss": false,
      "nextScriptWorkers": false,
      "scrollRestoration": false,
      "externalDir": false,
      "devMemoryThresholdRestart": true,
      "disableOptimizedLoading": false,
      "gzipSize": true,
      "craCompat": false,
      "esmExternals": true,
      "fullySpecified": false,
      "swcTraceProfiling": false,
      "forceSwcTransforms": false,
      "requestInsights": false,
      "largePageDataBytes": 128000,
      "typedEnv": false,
      "parallelServerCompiles": false,
      "parallelServerBuildTraces": false,
      "ppr": false,
      "authInterrupts": false,
      "webpackMemoryOptimizations": false,
      "optimizeServerReact": true,
      "strictRouteTypes": false,
      "useTypeScriptCli": true,
      "removeUncaughtErrorAndRejectionListeners": false,
      "validateRSCRequestHeaders": true,
      "staleTimes": {
        "dynamic": 0,
        "static": 300
      },
      "reactDebugChannel": true,
      "serverComponentsHmrCache": true,
      "serverComponentsHmrCancellation": false,
      "staticGenerationMaxConcurrency": 8,
      "staticGenerationMinPagesPerWorker": 25,
      "transitionIndicator": false,
      "gestureTransition": false,
      "inlineCss": false,
      "useCache": false,
      "useCacheStaticRootParamTracking": false,
      "globalNotFound": false,
      "explicitParallelRouteChildren": true,
      "strictRouteMatching": true,
      "browserDebugInfoInTerminal": "warn",
      "lockDistDir": true,
      "disableResumeDataCacheCompression": false,
      "proxyClientMaxBodySize": 10485760,
      "hideLogsAfterAbort": false,
      "mcpServer": true,
      "exposeRuntimeErrorsToHMR": false,
      "turbopackFileSystemCacheForDev": true,
      "turbopackFileSystemCacheForBuild": true,
      "turbopackStaleOutputMaxAge": 604800000,
      "turbopackInferModuleSideEffects": true,
      "turbopackPluginRuntimeStrategy": "childProcesses",
      "turbopackSharedRuntime": true,
      "optimizePackageImports": [
        "lucide-react",
        "date-fns",
        "@rosegriffon/ui",
        "@rosegriffon/azalee",
        "motion",
        "react-hook-form",
        "@hookform/resolvers",
        "react-icons",
        "recharts",
        "cmdk",
        "embla-carousel-react",
        "input-otp",
        "react-day-picker",
        "zustand",
        "@tanstack/react-query",
        "@tanstack/react-query-persist-client",
        "@tanstack/react-table",
        "@tiptap/core",
        "@tiptap/react",
        "@tiptap/starter-kit",
        "clsx",
        "tailwind-merge",
        "class-variance-authority",
        "sonner",
        "zod",
        "lodash-es",
        "ramda",
        "antd",
        "react-bootstrap",
        "ahooks",
        "@ant-design/icons",
        "@headlessui/react",
        "@headlessui-float/react",
        "@heroicons/react/20/solid",
        "@heroicons/react/24/solid",
        "@heroicons/react/24/outline",
        "@visx/visx",
        "@tremor/react",
        "rxjs",
        "@mui/material",
        "@mui/icons-material",
        "react-use",
        "effect",
        "@effect/schema",
        "@effect/platform",
        "@effect/platform-node",
        "@effect/platform-browser",
        "@effect/platform-bun",
        "@effect/sql",
        "@effect/sql-mssql",
        "@effect/sql-mysql2",
        "@effect/sql-pg",
        "@effect/sql-sqlite-node",
        "@effect/sql-sqlite-bun",
        "@effect/sql-sqlite-wasm",
        "@effect/sql-sqlite-react-native",
        "@effect/rpc",
        "@effect/rpc-http",
        "@effect/typeclass",
        "@effect/experimental",
        "@effect/opentelemetry",
        "@material-ui/core",
        "@material-ui/icons",
        "@tabler/icons-react",
        "mui-core",
        "react-icons/ai",
        "react-icons/bi",
        "react-icons/bs",
        "react-icons/cg",
        "react-icons/ci",
        "react-icons/di",
        "react-icons/fa",
        "react-icons/fa6",
        "react-icons/fc",
        "react-icons/fi",
        "react-icons/gi",
        "react-icons/go",
        "react-icons/gr",
        "react-icons/hi",
        "react-icons/hi2",
        "react-icons/im",
        "react-icons/io",
        "react-icons/io5",
        "react-icons/lia",
        "react-icons/lib",
        "react-icons/lu",
        "react-icons/md",
        "react-icons/pi",
        "react-icons/ri",
        "react-icons/rx",
        "react-icons/si",
        "react-icons/sl",
        "react-icons/tb",
        "react-icons/tfi",
        "react-icons/ti",
        "react-icons/vsc",
        "react-icons/wi"
      ],
      "serverActions": {
        "bodySizeLimit": "5mb"
      },
      "serverSourceMaps": true,
      "turbo": {
        "rules": {
          "*.lua": {
            "loaders": [
              "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
            ],
            "as": "*.js"
          },
          "*.luac": {
            "loaders": [
              "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
            ],
            "as": "*.js"
          },
          "*.lua.bin": {
            "loaders": [
              "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
            ],
            "as": "*.js"
          }
        }
      },
      "turbopackMemoryEvictionMode": "auto",
      "useCacheTimeout": 54,
      "instantInsights": {
        "validationLevel": "warning"
      },
      "trustHostHeader": false,
      "isExperimentalCompile": false
    },
    "htmlLimitedBots": "[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight",
    "bundlePagesRouterDependencies": false,
    "configFileName": "next.config.ts",
    "reactCompiler": true,
    "turbopack": {
      "root": "C:\\src\\apps\\rosegriffon",
      "rules": {
        "*.lua": {
          "loaders": [
            "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
          ],
          "as": "*.js"
        },
        "*.luac": {
          "loaders": [
            "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
          ],
          "as": "*.js"
        },
        "*.lua.bin": {
          "loaders": [
            "C:\\src\\apps\\rosegriffon\\packages\\rg-lua\\src\\loader.js"
          ],
          "as": "*.js"
        }
      }
    },
    "transpilePackages": [
      "@rosegriffon/inagle",
      "@rosegriffon/inagle-cross",
      "@rosegriffon/azalee",
      "@rosegriffon/ui",
      "@rosegriffon/app-shell",
      "@rosegriffon/db",
      "@rosegriffon/types",
      "@rosegriffon/config",
      "@rosegriffon/patreon-bun",
      "@rosegriffon/auth",
      "@rosegriffon/assets",
      "@rosegriffon/lua-plugin",
      "@rosegriffon/achillea-types",
      "@rosegriffon/achillea-core",
      "@rosegriffon/achillea-client",
      "@aphrody/sql",
      "@aphrody/paths",
      "@aphrody/agent-browser",
      "@aphrody/bun-plugin-tailwind",
      "@aphrody/filmcraft",
      "@aphrody/hyperframes",
      "@aphrody/m3-tailwind",
      "@aphrody/m3-tokens",
      "@aphrody/next-bun",
      "@aphrody/nie-ui",
      "@aphrody/runtime-sdk",
      "@rosegriffon/i18n",
      "@rosegriffon/preferences",
      "@rosegriffon/search"
    ],
    "serverExternalPackages": [
      "@sentry/nextjs",
      "better-auth",
      "@better-auth/kysely-adapter",
      "kysely",
      "discord.js",
      "googleapis",
      "nodemailer",
      "pg",
      "stripe",
      "pica",
      "xlsx",
      "jsonwebtoken",
      "web-push",
      "konva",
      "csv-parse"
    ],
    "repoRoot": "C:\\src\\apps\\rosegriffon",
    "distDirRoot": ".next",
    "supportsImmutableAssets": false
  },
  "appDir": "C:\\src\\apps\\rosegriffon\\apps\\rg-website",
  "relativeAppDir": "apps\\rg-website",
  "files": [
    ".next\\package.json",
    ".next\\routes-manifest.json",
    ".next\\server\\pages-manifest.json",
    ".next\\build-manifest.json",
    ".next\\prerender-manifest.json",
    ".next\\server\\preview-props.json",
    ".next\\server\\functions-config-manifest.json",
    ".next\\server\\middleware-manifest.json",
    ".next\\server\\middleware-build-manifest.js",
    ".next\\server\\middleware-react-loadable-manifest.js",
    ".next\\react-loadable-manifest.json",
    ".next\\server\\app-paths-manifest.json",
    ".next\\app-path-routes-manifest.json",
    ".next\\server\\server-reference-manifest.js",
    ".next\\server\\server-reference-manifest.json",
    ".next\\server\\prefetch-hints.json",
    ".next\\BUILD_ID",
    ".next\\server\\next-font-manifest.js",
    ".next\\server\\next-font-manifest.json",
    ".next\\required-server-files.json",
    ".next\\server\\instrumentation.js",
    ".next\\server\\edge-instrumentation.js"
  ],
  "ignore": []
}